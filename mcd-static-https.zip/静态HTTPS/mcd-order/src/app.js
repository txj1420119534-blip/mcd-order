import {products,stores,locations,coupons,task} from './fixtures.js';
import {money,quote,suggestions,settle} from './rules.js';
import {art} from './art.js';
import {initial,restore} from './storage.js';
import {categories,matchingProducts,futureReward,nextOrderId,receiptSummary} from './view-model.js';

const storageKey='mcd-order-demo-v2',guideKey='mcd-order-guide-v1';
let state=structuredClone(initial),storageIssue='',restoreWarning='',guideVisible=true,raw;
try{raw=localStorage.getItem(storageKey);guideVisible=localStorage.getItem(guideKey)!=='seen';}
catch{storageIssue='浏览器已关闭本地存储。本次仍可完整试玩，刷新后不会保留记录。';}
if(raw)try{state=restore(raw);}catch{restoreWarning='上次存档未通过校验，已恢复初始餐单。';}
let lastReceipt=state.ledger[0]||null,toastTimer;
const app=document.querySelector('#app');
function persist(){
 if(storageIssue)return;
 try{localStorage.setItem(storageKey,JSON.stringify(state));}
 catch{storageIssue='浏览器无法保存记录。本次仍可完整试玩，刷新后不会保留更改。';}
}
function toast(text){
 const node=document.querySelector('#toast');node.textContent=text;node.classList.add('show');
 clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.classList.remove('show'),3400);
}
const options=(items,value)=>items.map(i=>`<option value="${i.id}" ${value===i.id?'selected':''}>${i.name}</option>`).join('');
function foodArt(product){
 if(!product.contents)return art(product.art);
 return `<div class="combo-art"><div class="combo-main">${art(product.art)}</div><div class="combo-side">${art('fries')}</div><div class="combo-drink">${art('cola')}</div></div>`;
}
function productCard(product){
 const quantity=state.cart[product.id]||0;
 return `<article class="product card ${quantity?'is-selected':''}" data-product="${product.id}">
  <div class="product-image ${product.art}">${product.tag?`<span class="product-tag">${product.tag}</span>`:''}${foodArt(product)}${quantity?`<span class="selected-tag">已选 ${quantity}</span>`:''}</div>
  <div class="product-info"><span class="product-category">${product.category}${product.contents?' · 套餐':''}</span><h3>${product.name}</h3><p>${product.contents||product.note}</p>
  <div class="product-bottom"><div><strong>${money(product.price)}</strong><small>演示单价</small></div><button class="add-button" data-add="${product.id}" aria-label="添加${product.name}"><span aria-hidden="true">＋</span></button></div></div>
 </article>`;
}
function receiptCard(order){
 const receipt=receiptSummary(order);
 return `<section class="receipt" id="receipt" tabindex="-1" aria-label="模拟订单完成回执"><span class="receipt-check" aria-hidden="true">✓</span><span class="eyebrow">ALL SET. ENJOY YOUR MEAL.</span><h3>这一餐，模拟完成！</h3><p>${receipt.id} · ${receipt.quantity} 份餐品</p><div class="receipt-amount"><span>本次账单参考</span><strong>${money(receipt.payable)}</strong></div><p class="receipt-safe">未产生付款，也没有发送真实订单。</p><div class="receipt-reward"><span>未来奖励记录</span><strong>${receipt.rewardCount} 张后续商品券</strong><small>${receipt.rewardCount?'已单独记账；本单抵扣 ¥0.00。':'本次未发券，原因可在订单记录中查看。'}</small></div><button id="continue-order" class="dark-button">再选一餐 <span aria-hidden="true">↗</span></button><a href="#ledger" class="text-link">查看完整记录</a></section>`;
}
function ledgerRow(order){
 return `<article class="ledger-row"><div class="ledger-number"><span aria-hidden="true">▤</span><div><strong>${order.id}</strong><small>本地模拟订单</small></div></div><div class="ledger-detail"><p>${Object.entries(order.cart).map(([id,n])=>`${products.find(p=>p.id===id).name} × ${n}`).join(' / ')}</p><p class="ledger-status">${order.status} · ${order.reward} 张后续商品券</p>${order.rewardCoupon?`<details><summary>查看未来券条件</summary><p>${order.rewardCoupon.name}</p><small>${order.rewardCoupon.condition} 本试玩仅保留奖励记录，不提供真实用券。</small></details>`:''}</div><strong class="ledger-paid">${money(order.quote.payable)}<small>账单参考</small></strong></article>`;
}
function render(){
 persist();
 const focus=document.activeElement?.id,focusLabel=document.activeElement?.getAttribute('aria-label'),focusTab=document.activeElement?.dataset.tab,q=quote(state),count=Object.values(state.cart).reduce((a,b)=>a+b,0),plans=suggestions(state),reward=futureReward(state,q);
 app.innerHTML=`
 <header class="topbar"><a class="brand" href="#" aria-label="麦麦点餐助手首页"><span class="brand-mark" aria-hidden="true">m</span><span>麦麦<span class="brand-light">点餐助手</span></span></a><nav aria-label="主导航"><a href="#menu">选好这一餐</a><a href="#benefits">优惠与奖励</a><a href="#ledger">模拟记录</a></nav><div class="top-actions"><span class="demo-pill"><i></i>本地试玩 · DEMO</span><button id="guide-open" class="help-button" aria-label="打开试玩指引">?</button></div></header>
 <main>
  <section class="hero" aria-labelledby="hero-title"><img id="hero-image" class="hero-photo" src="assets/order-hero.png" alt="汉堡、金黄薯条与饮品的AI原创概念图，非官方实物图"><div class="hero-copy"><span class="eyebrow">GOOD FOOD. YOUR CALL.</span><h1 id="hero-title">想吃的，<span>刚刚好。</span></h1><p>先选喜欢的，再把账单看明白。<br>这一餐，按你的胃口来。</p><div class="hero-actions"><a class="primary-button" href="#menu">开始选餐 <span aria-hidden="true">↗</span></a><button data-guide class="hero-guide">30 秒上手 <span aria-hidden="true">→</span></button></div><div class="hero-tags"><span>✓ 本单实付透明</span><span>✓ 不为奖励凑单</span></div></div><span class="hero-caption">今天，也好好吃饭。<small>AI原创概念图 · 非商品实拍</small></span></section>
  <div class="fixture-banner"><span class="notice-dot" aria-hidden="true"></span><strong>放心试玩</strong><p>演示菜单、价格和权益，仅生成本地记录，不会真实下单或付款。</p><a href="#data-reference">资料与边界说明 ↗</a></div>
  ${storageIssue?`<p id="storage-warning" class="storage-warning" role="status">${storageIssue}</p>`:''}${restoreWarning?`<p class="storage-warning" role="status">${restoreWarning}</p>`:''}
  ${guideVisible?`<section class="quick-guide" aria-label="试玩指引"><div><span class="eyebrow">YOUR FIRST LITTLE MEAL</span><h2>第一次来？跟着走一遍。</h2></div><ol><li><b>01</b><span>选你喜欢的<small>分类找餐，点击加号</small></span></li><li><b>02</b><span>看清本单账单<small>优惠与未来奖励分开看</small></span></li><li><b>03</b><span>确认模拟下单<small>生成记录，无需支付</small></span></li></ol><button id="guide-close" class="guide-close" aria-label="收起试玩指引">知道了 <span aria-hidden="true">×</span></button></section>`:''}
  <section class="setup card" aria-label="演示取餐设置"><div class="store-control"><label for="store"><span>01</span> 选择门店</label><select id="store">${options(stores,state.storeId)}</select><small>${stores.find(s=>s.id===state.storeId)?.address||'门店信息缺失'}</small></div><div class="fulfill-control"><span class="control-label"><span>02</span> 取餐方式</span><div class="segmented"><button data-mode="pickup" aria-pressed="${state.mode==='pickup'}" class="${state.mode==='pickup'?'active':''}">到店自取</button><button data-mode="delivery" aria-pressed="${state.mode==='delivery'}" class="${state.mode==='delivery'?'active':''}">配送演示</button></div><small>${state.mode==='pickup'?'自取不收配送费':'按演示门店与候选点校验范围'}</small></div><div class="member-control"><label for="member"><span>03</span> 体验身份</label><select id="member"><option value="guest" ${state.member==='guest'?'selected':''}>游客</option><option value="member" ${state.member==='member'?'selected':''}>普通会员 · DEMO</option><option value="gold" ${state.member==='gold'?'selected':''}>金卡会员 · DEMO</option><option value="plus" ${state.member==='plus'?'selected':''}>PLUS 会员 · DEMO</option></select><small>金卡满 ¥39 减 ¥5；PLUS 另免配送费</small></div>${state.mode==='delivery'?`<div class="location-control"><label for="location">配送候选点 · 非个人地址</label><select id="location">${options(locations,state.locationId)}</select><small>演示匹配：${stores.filter(s=>s.enabled&&s.locations.includes(state.locationId)).map(s=>s.name).join('、')||'暂无门店'}。不代表真实可配送范围。</small></div>`:''}</section>
  <div class="layout"><div class="left-column">
   <section id="menu" aria-labelledby="menu-title"><div class="section-heading"><div><span class="eyebrow">A MENU FOR YOUR MOOD</span><h2 id="menu-title">这一餐，想吃什么？</h2></div><span class="tiny-label">9 款演示餐品</span></div><div class="menu-toolbar"><div class="tabs" role="group" aria-label="餐品分类">${categories.map(category=>`<button data-tab="${category}" aria-pressed="${state.tab===category}" class="${state.tab===category?'active':''}">${category}</button>`).join('')}</div><label class="search"><span aria-hidden="true">⌕</span><input id="search" type="search" aria-label="搜索餐品" placeholder="找找想吃的" autocomplete="off"></label></div><div class="menu-meta"><p id="menu-result" role="status"></p><button id="clear-search" class="text-button" hidden>清除筛选</button></div><div class="product-grid">${products.map(productCard).join('')}</div><div id="no-results" class="no-results" hidden><span aria-hidden="true">⌕</span><h3>暂时没找到这道美味</h3><p>换个关键词，或看看全部餐品。</p><button data-show-all class="outline-button">查看全部餐品</button></div></section>
   <section id="benefits" class="benefits card"><div class="section-heading"><div><span class="eyebrow">A LITTLE EXTRA, FOR LATER</span><h2>吃得开心，奖励随缘。</h2></div><span class="points-icon" aria-hidden="true">✦</span></div><div class="task-row"><div><span class="future-label">未来奖励 · 不抵本单</span><h3>${task.title}</h3><p>按全部优惠后的餐品实付计算，不含配送费。想体验再领取，不必加购。</p></div><button id="claim" class="${state.claimed?'subtle-button':'dark-button'}" ${state.claimed||state.member==='guest'?'disabled':''}>${state.claimed?'已领取 ✓':state.member==='guest'?'游客无需领任务':'领取演示任务'}</button></div><div class="progress-track" role="progressbar" aria-label="未来奖励任务进度" aria-valuemin="0" aria-valuemax="28" aria-valuenow="${q.ok?Math.min(28,q.foodPaid/100):0}"><span style="width:${q.ok?Math.min(100,q.foodPaid/task.threshold*100):0}%"></span></div><div class="task-foot"><strong>${!q.ok?'暂无法报价':q.qualifies?'餐品实付已达到演示门槛':`餐品实付 ${money(q.foodPaid)} / ¥28.00`}</strong><span>${state.claimed?'已领取任务':'需在模拟下单前领取'}</span></div><details class="rules-details"><summary>看看奖励条件</summary><p>${task.rewardCondition} 奖励仅为本地记录；本单抵扣 ¥0.00，不代表真实发券或可用券。</p></details></section>
   <section class="comparison" id="compare"><div class="section-heading"><div><span class="eyebrow">YOUR CALL, ALWAYS</span><h2>搭配建议，决定权在你。</h2></div></div><p class="section-intro">每个方案都展示本单实付和实际多花、少花的金额。原单始终保留。</p><div class="plan-grid">${plans.length?plans.map((plan,index)=>`<article class="plan card ${index===0?'recommended':''}"><span class="plan-label">${index===0?'原单 · 零增量':plan.id==='add'?'想吃再加':'换个口味'}</span><h3>${plan.title}</h3><p>${plan.description}</p><div class="plan-total">${money(plan.quote.payable)}<small>本单实付 · 含配送</small></div><div class="plan-delta">${plan.increment===0?'不额外消费':`${plan.increment>0?'多付':'少付'} ${money(Math.abs(plan.increment))}`}</div><small class="plan-qualification">未来奖励本单抵扣 ¥0.00</small><button data-plan="${plan.id}" class="${index===0?'dark-button':'outline-button'}">${index===0?'保持原单':'选择此方案'}</button></article>`).join(''):'<div class="empty card">选好一份餐品，搭配建议就会出现在这里。报价不可用时不生成建议。</div>'}</div></section>
   <details class="cost-lab card"><summary><span><span class="eyebrow">A CLEARER LITTLE BILL</span><strong>为什么“减了 ¥5”，仍可能多花钱？</strong></span><span aria-hidden="true">＋</span></summary><div class="cost-content"><p>加购有新增价格，优惠也有使用条件。下面两个例子可以载入购物袋，亲自比较。</p><div class="example-actions"><button data-example="meal30" class="outline-button">体验 ¥30 原餐</button><button data-example="meal37" class="outline-button">体验 ¥37 原餐</button></div><div class="cost-example"><span>原餐 ¥30.00 ＋ 甜点 ¥9.90 − 金卡 ¥5.00</span><strong>实付 ¥34.90</strong><b>多付 ¥4.90，增加一份甜点</b></div><div class="cost-example"><span>原餐 ¥37.00 ＋ 甜点 ¥9.90 − 金卡 ¥5.00</span><strong>实付 ¥41.90</strong><b>多付 ¥4.90，增加一份甜点</b></div><small>不想吃甜点，就保留原餐。演示规则不代表当前官方活动。</small></div></details>
   <section id="ledger" class="ledger card"><div class="section-heading"><div><span class="eyebrow">YOUR LITTLE MEAL JOURNAL</span><h2>每一餐，都记得清楚。</h2></div><button id="reset" class="outline-button">重置试玩</button></div>${state.ledger.length?state.ledger.map(ledgerRow).join(''):'<div class="ledger-empty"><span aria-hidden="true">▤</span><h3>还没有模拟订单</h3><p>完成一餐后，这里会分别记录账单与未来奖励。</p><small>记录仅存于当前浏览器；不关联任何真实账户。</small></div>'}</section>
  </div>
  <aside class="cart card" id="cart" aria-label="我的购物袋">${lastReceipt&&!count?receiptCard(lastReceipt):''}<div class="cart-heading"><div><span class="eyebrow">YOUR LITTLE BAG</span><h2>我的购物袋 <span>${count}</span></h2></div>${count?'<button id="clear-cart" class="text-button">清空</button>':'<span aria-hidden="true">♧</span>'}</div><p class="cart-sub">喜欢多少，就选多少。</p><div class="cart-lines">${products.filter(product=>state.cart[product.id]>0).map(product=>`<div class="cart-line"><div class="cart-art">${art(product.art)}</div><div class="cart-product"><h3>${product.name}</h3><small>${money(product.price)} / 份</small>${product.contents?`<small class="bundle-contents">${product.contents}</small>`:''}<div class="quantity"><button data-minus="${product.id}" aria-label="减少${product.name}">−</button><span aria-label="${product.name}数量">${state.cart[product.id]}</span><button data-add="${product.id}" aria-label="增加${product.name}">＋</button></div></div><strong>${money(product.price*state.cart[product.id])}</strong></div>`).join('')||'<div class="empty-cart"><span aria-hidden="true">♧</span><h3>购物袋还空着</h3><p>去菜单选点喜欢的，或从轻松一餐开始。</p><button data-example="meal30" class="outline-button">加入 ¥30 轻松一餐</button></div>'}</div><div class="coupon-field"><label for="coupon">本单商品券 <span>每单最多 1 张</span></label><select id="coupon">${options(coupons,state.couponId)}</select>${q.ok&&state.couponId!=='none'&&!q.couponApplied?'<small class="warning-text">未选中适用餐品，这张商品券没有抵扣。</small>':''}</div>${q.ok?`<div class="bill-title">本单账单 <span>所有金额均为演示</span></div><dl class="totals"><div><dt>餐品金额</dt><dd>${money(q.subtotal)}</dd></div><div class="saving"><dt>商品券优惠</dt><dd>−${money(q.discount)}</dd></div><div class="saving"><dt>金卡满 ¥39 减 ¥5</dt><dd>−${money(q.goldDiscount)}</dd></div><div><dt>配送费</dt><dd>${money(q.deliveryFee)}</dd></div><div class="saving"><dt>PLUS 配送权益</dt><dd>−${money(q.deliveryBenefit)}</dd></div></dl><details class="member-rule"><summary>查看本单优惠怎么算</summary><p>金卡门槛以商品券后、金卡优惠前的餐品额 ${money(q.memberEligibleBase)} / ¥39.00 判断，不含配送。金卡/PLUS 身份可用满减，PLUS 另免配送费。可与 1 张适用商品券叠加；均为演示规则。</p></details><div class="grand-total"><span>本单实付 <small>模拟账单，无真实付款</small></span><strong>${money(q.payable)}</strong></div>`:`<div class="error" role="alert">${q.error}。请更换设置后再试，当前无法模拟下单。</div>`}<div class="future-reward ${reward.kind}"><div><span aria-hidden="true">✦</span><strong>未来奖励</strong><b>本单抵扣 ¥0.00</b></div><p>${reward.title}</p><small>${reward.detail}</small>${!state.claimed&&state.member!=='guest'?'<a href="#benefits">按需体验领任务 →</a>':''}</div><button id="checkout" class="checkout" ${!q.ok||!count?'disabled':''}><span>确认模拟下单</span><span aria-hidden="true">→</span></button><p class="checkout-note">不付款 · 不发送真实订单 · 不消耗真实积分</p></aside></div>
  <footer><a class="footer-brand" href="#">麦麦 · 点餐助手</a><p>独立创意原型，非麦当劳官方产品。<br>真实信息以官方渠道的实时结果为准。</p><button data-reset class="text-button">恢复初始试玩 ↻</button></footer>
 </main><a class="mobile-bag" href="#cart" aria-label="查看购物袋"><span class="mobile-bag-count">${count}</span><span><strong>我的购物袋</strong><small>${q.ok?money(q.payable):'请先检查取餐设置'} · 模拟账单</small></span><b>查看账单 <span aria-hidden="true">↑</span></b></a>`;
 document.querySelector('#search').value=state.search;filterProducts();bind();
 const focusTarget=focus?document.getElementById(focus):focusLabel?document.querySelector(`[aria-label="${CSS.escape(focusLabel)}"]`):focusTab?document.querySelector(`[data-tab="${CSS.escape(focusTab)}"]`):null;
 focusTarget?.focus({preventScroll:true});
}
function filterProducts(){
 const matching=new Set(matchingProducts(state).map(product=>product.id));
 document.querySelectorAll('[data-product]').forEach(node=>{node.hidden=!matching.has(node.dataset.product);});
 document.querySelector('#no-results').hidden=matching.size>0;
 document.querySelector('#menu-result').textContent=state.search.trim()?`找到 ${matching.size} 款餐品`:`${state.tab} · ${matching.size} 款餐品`;
 document.querySelector('#clear-search').hidden=!state.search&&state.tab==='全部';
}
function scrollTo(id){document.getElementById(id)?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});}
function showGuide(){guideVisible=true;render();document.querySelector('.quick-guide')?.scrollIntoView({behavior:'smooth',block:'center'});}
function resetDemo(){state=structuredClone(initial);lastReceipt=null;restoreWarning='';render();toast('已恢复初始餐单，并清空本地模拟订单与奖励记录。');}
function bind(){
 const hero=document.getElementById('hero-image');hero.onerror=()=>{hero.onerror=null;hero.src='assets/order-hero.svg';};
 document.querySelectorAll('[data-add]').forEach(button=>button.onclick=()=>{const id=button.dataset.add;if((state.cart[id]||0)>=99)return toast('单品最多 99 份。');state.cart[id]=(state.cart[id]||0)+1;render();toast(`已加入${products.find(product=>product.id===id).name}`);});
 document.querySelectorAll('[data-minus]').forEach(button=>button.onclick=()=>{state.cart[button.dataset.minus]--;if(!state.cart[button.dataset.minus])delete state.cart[button.dataset.minus];render();});
 document.querySelectorAll('[data-mode]').forEach(button=>button.onclick=()=>{state.mode=button.dataset.mode;render();});
 document.querySelectorAll('[data-tab]').forEach(button=>button.onclick=()=>{state.tab=button.dataset.tab;render();});
 for(const [id,key] of [['store','storeId'],['location','locationId'],['coupon','couponId'],['member','member']]){
  const element=document.getElementById(id);if(element)element.onchange=()=>{state[key]=element.value;if(key==='member'||key==='storeId')state.claimed=false;render();};
 }
 document.querySelector('#search').oninput=event=>{state.search=event.target.value;filterProducts();};
 const clearFilters=()=>{state.search='';state.tab='全部';render();document.querySelector('#search').focus({preventScroll:true});};
 document.querySelector('#clear-search').onclick=clearFilters;document.querySelector('[data-show-all]').onclick=clearFilters;
 document.querySelector('#claim').onclick=()=>{if(state.member==='guest')return;state.claimed=true;render();toast('已领取演示任务。未来商品券单独记账，不抵本单。');};
 document.querySelectorAll('[data-plan]').forEach(button=>button.onclick=()=>{if(button.dataset.plan==='keep')return toast('保留原单，不增加消费。');const plan=suggestions(state).find(item=>item.id===button.dataset.plan);if(!plan)return;state.cart={...plan.cart};render();toast('已按你的选择更新购物袋，实付金额已重新计算。');});
 document.querySelectorAll('[data-example]').forEach(button=>button.onclick=()=>{state.cart={[button.dataset.example]:1};state.member='gold';state.couponId='none';state.mode='pickup';state.storeId='river';state.claimed=false;render();toast('已载入原餐：金卡、自取、不用商品券。是否加购由你决定。');});
 document.querySelector('#reset').onclick=resetDemo;document.querySelector('[data-reset]').onclick=resetDemo;
 const clear=document.querySelector('#clear-cart');if(clear)clear.onclick=()=>{state.cart={};state.claimed=false;lastReceipt=null;render();toast('已清空购物袋，模拟订单记录仍然保留。');};
 document.querySelector('#checkout').onclick=()=>{
  try{const order=settle(state,nextOrderId(state.ledger));state.ledger.unshift(order);state.cart={};state.claimed=false;lastReceipt=order;render();document.querySelector('#receipt')?.focus({preventScroll:true});scrollTo('receipt');toast('模拟完成。未产生付款，账单与未来奖励已分别记录。');}
  catch(error){toast(error.message);}
 };
 document.querySelector('#guide-open').onclick=showGuide;document.querySelector('[data-guide]').onclick=showGuide;
 const closeGuide=document.querySelector('#guide-close');if(closeGuide)closeGuide.onclick=()=>{guideVisible=false;try{localStorage.setItem(guideKey,'seen');}catch{storageIssue='浏览器已关闭本地存储。本次仍可完整试玩，刷新后不会保留记录。';}render();};
 const continueOrder=document.querySelector('#continue-order');if(continueOrder)continueOrder.onclick=()=>{lastReceipt=null;render();scrollTo('menu');};
}
render();
