import {MENU,THEMES,getTheme,themeAgenda,fresh,validate,totals,coverage,changeQuantity,recommend,trimExtras,agendaErrors,planReadiness,save,restore,shareText} from './core.js';

let state;
let storageAvailable=true;
let lastSaved='';
try { state=restore(localStorage); } catch { state=fresh(); storageAvailable=false; }
const stores={'上海':['静安灵感店','浦东好时光店'],'北京':['朝阳相聚店','海淀灵感店'],'广州':['天河好时光店','越秀相聚店']};
const sessions=['午间 12:00–14:00','下午 14:00–16:00','晚间 18:00–20:00'];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>Number(n).toLocaleString('zh-CN',{minimumFractionDigits:0,maximumFractionDigits:2});
const options=(items,value)=>items.map(x=>`<option ${x===value?'selected':''}>${esc(x)}</option>`).join('');
function foodArt(id){
 const buns='<path d="M13 23C13 7 51 7 51 23Z" fill="#edb34c"/><path d="M12 26h40v6H12" fill="#75a751"/><path d="M13 33h38v6H13" fill="#854933"/><path d="M13 42h38c0 11-38 11-38 0" fill="#eeb65a"/><path d="m24 16 3-2m10 1 3 2" stroke="#fff1c4" stroke-width="2" stroke-linecap="round"/>';
 const drawings={burger:buns,chicken:buns.replace('#854933','#ce812e'),fries:'<path d="m18 11 4 27m8-31 1 31m10-28-4 28m10-22-4 23" stroke="#efba3c" stroke-width="7"/><path d="m12 29 8 24h25l7-24Z" fill="#d8312b"/><path d="m25 41 4-6 4 6 5-6 3 7" fill="none" stroke="#ffdf76" stroke-width="3"/>',nuggets:'<path d="M12 34 20 53h29l6-19" fill="#e5caa5"/><path d="M17 29c-8-16 16-22 20-9 17-10 26 13 11 17-8 9-34 7-31-8" fill="#d9a44a"/><path d="m22 21 3 2m17 3 3-2" stroke="#f2ca7b" stroke-width="3"/>',drink:'<path d="M35 7 30 28" stroke="#a17bba" stroke-width="4"/><path d="m16 21 5 34h24l5-34Z" fill="#d8312b"/><path d="M16 20h34" stroke="#fff1cf" stroke-width="6"/><path d="m28 39 4-8 4 8 4-8" fill="none" stroke="#ffdb66" stroke-width="3"/>',tea:'<path d="m38 6-8 20" stroke="#68794a" stroke-width="4"/><path d="m17 22 5 32h23l5-32Z" fill="#bed292"/><path d="M17 21h33" stroke="#f3efda" stroke-width="6"/><path d="M26 40c2-11 13-9 14-9-1 11-10 13-14 9Z" fill="#728b47"/>',dessert:'<path d="m24 35 9 22 10-22" fill="#dfae62"/><path d="M20 34c-5-9 4-15 7-15-2-8 12-14 13-5 10 1 8 10 6 12 11 12-17 14-26 8" fill="#fff5d8"/><path d="m29 44 9 4m-7-8 10 3" stroke="#ba863f" stroke-width="1.5"/>'};
 return `<svg viewBox="0 0 64 64" aria-hidden="true">${drawings[id]||buns}</svg>`;
}
function themeArt(id){
 if(id==='birthday')return '<svg viewBox="0 0 180 100" aria-hidden="true"><path d="M20 20Q90 50 160 20" fill="none" stroke="#ac8cbe" stroke-width="2"/><path d="m35 26 8 16 10-11m26 2 10 17 10-17m26-2 10 11 10-16" fill="#dfb4c8"/><ellipse cx="90" cy="85" rx="45" ry="7" fill="#c7b0d7"/><path d="M55 62h70v22H55Z" fill="#f7e5ca"/><path d="M55 62q8-12 16 0 9 10 18 0 9-10 18 0 9 10 18 0" fill="#d77a84"/><path d="M66 61V48h48v13" fill="#ffcf75"/><path d="M89 48V34" stroke="#9358a7" stroke-width="4"/><path d="M89 33c-11-8 7-15 0-20 13 11 9 16 0 20" fill="#f6ad3b"/></svg>';
 if(id==='friends')return '<svg viewBox="0 0 180 100" aria-hidden="true"><ellipse cx="90" cy="83" rx="62" ry="9" fill="#c0d7a7"/><path d="m34 37 7 44h40l6-44" fill="#ee8070"/><path d="m91 32 6 49h40l6-49" fill="#ecc668"/><path d="m52 17 11 32m55-36-8 28" stroke="#587c50" stroke-width="5"/><path d="M34 37h53m4-5h52" stroke="#fff4d7" stroke-width="7"/><path d="m94 11 2 8m8-10 3-5m-25 6-5-5" stroke="#a97cbd" stroke-width="3"/><path d="M53 59q10 15 20 0m32-5q9 15 20 0" fill="none" stroke="#fff9ec" stroke-width="3"/></svg>';
 return '<svg viewBox="0 0 180 100" aria-hidden="true"><ellipse cx="90" cy="86" rx="57" ry="8" fill="#ead58f"/><path d="m37 42 53-16 53 16v38l-53-8-53 8Z" fill="#fff9e7"/><path d="M90 28v43" stroke="#d7be75" stroke-width="2"/><path d="m48 48 29-9m-29 20 29-9m25-9 29 8m-29 3 29 8" stroke="#baaf99" stroke-width="3"/><path d="M100 15h30v20h-30l-8 7 2-14" fill="#d9bddc"/><path d="m111 19 3 5 5-5" fill="none" stroke="#8e639f" stroke-width="2"/><path d="m46 22 4-9 4 9 10 2-8 5 1 10-7-6-8 5 2-10-8-5Z" fill="#d97a55"/></svg>';
}
function persist(){
 try { save(localStorage,state); storageAvailable=true; lastSaved='已自动保存'; }
 catch { storageAvailable=false; lastSaved='本次仅在内存中'; }
}
function notify(text){
 const node=document.querySelector('#toast');node.textContent=text;node.classList.add('visible');
 clearTimeout(window.partyToastTimer);window.partyToastTimer=setTimeout(()=>node.classList.remove('visible'),4200);
}
function setStep(step){
 if(step===3&&agendaErrors(state.agenda).length){notify(agendaErrors(state.agenda)[0]);return;}
 state.step=step;persist();render();document.querySelector('#workspace').scrollIntoView({behavior:'smooth',block:'start'});
}
function render(){
 const t=totals(state),theme=getTheme(state.theme);
 document.querySelector('#app').innerHTML=`
 <header class="site-header"><a href="index.html" class="brand" aria-label="快乐组局所首页"><span class="brand-mark">✳</span><span>快乐组局所<small>PARTY STUDIO <em>18+ · 演示</em></small></span></a><nav aria-label="主导航"><a href="#workspace">开始组局</a><button id="about" class="navlink">怎么玩 <span>↗</span></button></nav><span class="demo-pill"><i></i>18+ 朋友聚会 · 本地演示</span></header>
 <main>
 <section class="hero"><div class="hero-copy"><div class="eyebrow"><span class="eyebrow-line"></span>GOOD FOOD. GREAT COMPANY.</div><h1>见个面，<br>把快乐<span>组起来。</span><span class="heading-spark">✳</span></h1><p>有好吃的，也有聊不完的话。<br>给大朋友的生日与日常，做一份刚刚好的聚会计划。</p><div class="hero-actions"><a class="primary hero-cta" href="#workspace">定制我的快乐局 <span>↗</span></a><button class="text-button" id="hero-guide">第一次来？30 秒上手 →</button></div><div class="hero-proof"><span class="friend-faces"><i>☺</i><i>✦</i><i>♡</i></span><span>2–30 位成年人 <b>·</b> 不用注册 <b>·</b> 随时带走计划</span></div></div><div class="hero-art"><div class="art-note">好日子，从「一起」开始</div><img src="assets/party-hero.png" alt="成年朋友围坐的暖光生日聚会概念场景，桌上有分享餐品与蛋糕"><span class="art-sticker">LET’S MAKE<br>GOOD MEMORIES <b>✳</b></span><span class="art-bottom-note">AI原创场景 · 非真实可订场地</span></div></section>
 <div class="intro-strip"><span>01 <b>选个主题</b></span><i>⟶</i><span>02 <b>搭份快乐餐</b></span><i>⟶</i><span>03 <b>安排小惊喜</b></span><i>⟶</i><span>04 <b>带着计划出发</b></span></div>
 <section id="workspace" class="workspace" aria-label="聚会计划编辑器"><div class="workspace-heading"><div><span class="eyebrow">YOUR KIND OF HAPPY</span><h2>这一局，听你安排。</h2></div><div class="save-indicator">${storageAvailable?'◉ '+lastSaved:'◌ 仅本次保留 · 记得下载'}</div></div>
 ${!storageAvailable?'<div class="storage-warning" role="status">当前浏览器无法保存本地草稿。你仍可完整试玩；关闭页面前请下载计划。</div>':''}
 <div class="studio"><aside class="steps"><span class="mini-label">LET’S MAKE A PLAN</span>${['先定个调','搭配快乐餐','安排好时光','我的聚会方案'].map((name,i)=>`<button class="step ${state.step===i?'active':''} ${state.step>i?'completed':''}" data-step="${i}" aria-current="${state.step===i?'step':'false'}"><span class="step-number">${state.step>i?'✓':'0'+(i+1)}</span><span>${name}<small>${['主题 · 人数 · 预算','餐品 · 份数 · 偏好','小活动 · 自由编辑','预览 · 下载 · 带走'][i]}</small></span><span class="step-arrow">↗</span></button>`).join('')}<div class="side-note"><span>✧</span><p>计划可以慢慢改，<br>见面这件事很值得。</p><small>私人创意计划<br>没有预约或付款</small></div><button data-reset class="text-button reset-button">↺ 一键重置计划</button></aside>
 <div class="editor">${state.step===0?preferences():state.step===1?meal():state.step===2?agenda():result()}</div>
 <aside class="summary">${ticket(t,theme)}<div class="tip-card"><span>✦ 组局小贴士</span><p>${['日期还没商量好？可以先留空。先把想见面的人和想做的事放进计划。','餐品份数可以自由调整。少肉不等于素食；配料与过敏原请向实际门店核实。','每段活动都可以改。给不想参加游戏的朋友，也留一点自由。','下载文件只保存在你的设备。由你决定是否分享给朋友，没有自动发送。'][state.step]}</p></div></aside></div></section>
 <section class="closing-note"><span class="closing-spark">✳</span><div><h2>有计划，也可以有临时的小惊喜。</h2><p>这份方案属于你们。真正见面时，好好吃饭、好好聊天就很好。</p></div><a href="#workspace" class="text-button">继续打磨我的计划 ↗</a></section>
 <details class="experience-notes"><summary>体验说明与数据边界 <span>独立非官方 · 演示餐单 · 无真实预订</span></summary><p>快乐组局所是面向 18 岁以上朋友的私人创意工具，不隶属于麦当劳。编辑器中的门店、时段、餐品和价格为固定演示数据，不代表真实可售套餐、场次余量或成交报价。实际价格、配料、过敏原与聚会许可请向真实门店核实。</p><p>下方官方公开查询区域展示历史时间戳快照，儿童主题商品仅保留其原适用范围；不转化为成人生日套餐。历史日期、场次和价格不是当前承诺。导入失败会保留原快照，不会回退成演示成功。</p></details>
 </main><footer><a class="brand footer-brand" href="index.html"><span class="brand-mark">✳</span><span>快乐组局所<small>MADE FOR MOMENTS TOGETHER.</small></span></a><div><span>18+ 私人创意计划 · 本地演示</span><button data-reset class="text-button">↺ 重新开始</button></div><p>© 2026 独立概念体验</p></footer>`;
 bind();
}
function ticket(t,theme){return `<div class="ticket"><div class="ticket-top"><span>YOUR HAPPY PLAN</span><b>✳</b></div><div class="ticket-main"><span class="ticket-tag">${esc(theme.eyebrow)}</span><h3>${theme.name}</h3><p class="ticket-date">${state.date?esc(state.date):'好日子，待定'} · ${esc(state.time)}</p><div class="summary-line"><span>一起快乐</span><strong>${state.people} 位成年人</strong></div><div class="summary-line"><span>人均预算</span><strong>¥${money(state.budget)}</strong></div></div><div class="ticket-divider"><span></span><i></i><span></span></div><div class="ticket-main"><div class="ticket-amount"><span>演示餐单合计</span><strong>¥${money(t.total)}</strong></div><div class="summary-line"><span>平均每人</span><strong>¥${t.perPerson.toFixed(2)}</strong></div><div class="budget-track" role="img" aria-label="已使用预算 ${Math.round(t.total/t.limit*100)}%"><i style="width:${Math.min(100,t.total/t.limit*100)}%;background:${t.remaining<0?'#d8312b':'#9e83bc'}"></i></div><p class="budget-note ${t.remaining<0?'over':''}">${t.remaining<0?'超出预算 ¥'+money(-t.remaining):'还留有 ¥'+money(t.remaining)+' 的弹性'}</p></div><div class="ticket-bottom">${esc(state.city)} · ${esc(state.store)}<small>虚构地点 · 未预约 · 非官方报价</small></div><div class="ticket-barcode" aria-hidden="true"></div></div>`;}
function preferences(){return `<div class="editor-head"><span class="chapter">01 / THE VIBE</span><h2>今天，为什么而相聚？</h2><p>选一个心情，把它变成你们的计划。</p></div><div class="theme-grid">${THEMES.map(t=>`<button class="theme ${state.theme===t.id?'selected':''}" data-theme="${t.id}" aria-pressed="${state.theme===t.id}" style="--theme-color:${t.color}"><span class="theme-art">${themeArt(t.id)}</span><span class="theme-label"><strong>${t.name}</strong><small>${t.tag}</small></span><i>${state.theme===t.id?'✓':'○'}</i></button>`).join('')}</div>
 <div class="fields"><label>哪天见面<input id="date" type="date" value="${esc(state.date)}"><small>还没商量好？先留空也可以</small></label><label>几点开始<input id="time" type="time" value="${esc(state.time)}"><small>私人计划时间，不锁定门店</small></label><div class="field"><label for="people">一起几个人？</label><div class="number-field"><input id="people" type="number" min="2" max="30" value="${state.people}"><span>位成年人</span></div><div class="quick-options">${[4,6,8,12].map(n=>`<button data-quick="people" data-value="${n}" aria-pressed="${state.people===n}" class="${state.people===n?'selected':''}">${n} 人</button>`).join('')}</div><small>2–30 位 · 仅限 18 岁及以上</small></div><div class="field"><label for="budget">每人打算花多少？</label><div class="number-field"><span>¥</span><input id="budget" type="number" min="20" max="500" value="${state.budget}"><span>/ 人</span></div><div class="quick-options">${[50,75,100].map(n=>`<button data-quick="budget" data-value="${n}" aria-pressed="${state.budget===n}" class="${state.budget===n?'selected':''}">¥${n}</button>`).join('')}</div><small>只计算演示餐饮，不含布置与交通</small></div></div>
 <details class="location-box"><summary><span>⌖ 灵感碰头地点</span><small>${esc(state.city)} · ${esc(state.store)} <b>演示</b></small></summary><div class="location-fields"><label>城市<select id="city">${options(Object.keys(stores),state.city)}</select></label><label>虚构门店<select id="store">${options(stores[state.city]||stores['上海'],state.store)}</select></label></div><label>演示时段<select id="session">${options(sessions,state.session)}</select></label><p>仅记录私人灵感地点，不查询、不锁定任何门店。时间可自行安排。</p></details>
 <div class="editor-actions"><span class="step-hint">接下来，把想吃的装进计划</span><button class="primary" id="next">搭配我的快乐餐 <span>→</span></button></div>`;}
function meal(){
 const c=coverage(state),t=totals(state);
 return `<div class="editor-head"><span class="chapter">02 / THE MENU</span><h2>喜欢的，分着吃更快乐。</h2><p>${state.people} 位朋友的餐单，丰俭由你。以下均为演示价格。</p></div><div class="diet-row"><label>搭配偏好<select id="diet">${[['regular','经典一起吃'],['lesssugar','少甜饮与甜点'],['lessmeat','减少肉类份数']].map(([v,label])=>`<option value="${v}" ${state.diet===v?'selected':''}>${label}</option>`).join('')}</select></label><button class="secondary" id="recommend">✧ 按人数重新推荐</button></div><div class="coverage-row"><span class="${c.mainMissing?'warning':''}">主食 <b>${c.main}</b> / ${state.people} 位</span><span class="${c.drinksMissing?'warning':''}">饮品 <b>${c.drinks}</b> / ${state.people} 位</span><span>小食甜点，自由分享</span></div>
 <div class="menu-list">${MENU.map(m=>`<div class="menu-item"><span class="food-icon">${foodArt(m.id)}</span><div class="food-detail"><b>${m.name}</b><small>${m.tag}</small></div><strong>¥${m.price}</strong><div class="quantity"><button data-quantity="${m.id}" data-delta="-1" aria-label="减少${m.name}" ${state.quantities[m.id]===0?'disabled':''}>−</button><output aria-label="${m.name}数量">${state.quantities[m.id]}</output><button data-quantity="${m.id}" data-delta="1" aria-label="增加${m.name}" ${state.quantities[m.id]===100?'disabled':''}>+</button></div></div>`).join('')}</div>
 ${t.remaining<0?`<div class="budget-alert"><div><b>超出预算 ¥${money(-t.remaining)}</b><p>可以减少分享小食或甜点，主食和饮品由你决定。</p></div><button id="trim-extras" class="secondary">帮我减少可选小食</button></div>`:''}
 <p class="small-warning">${c.mainMissing?'主食少于人数，请确认分享安排。':''}偏好不是过敏原筛选；减少肉类不等于完整素食。实际配料与饮食适用性需向门店核实。</p><div class="editor-actions"><button class="text-button" data-step="0">← 返回调整</button><button class="primary" id="next">安排好时光 <span>→</span></button></div>`;
}
function agenda(){return `<div class="editor-head"><span class="chapter">03 / THE MOMENTS</span><h2>给相聚，留一点小惊喜。</h2><p>四段轻松流程。点开文字，写成你们自己的版本。</p></div><div class="agenda-tip"><span>✦</span><p>时间从聚会开始后计算。活动都自愿参与，留白也很好。</p></div><div class="agenda-list">${state.agenda.map((a,i)=>`<div class="agenda-item"><span class="agenda-dot">${['✳','♡','✦','☺'][i]}</span><div><label class="agenda-time">开始后 <input data-agenda="${i}" data-key="time" value="${esc(a.time)}" maxlength="5" aria-label="活动${i+1}相对时间" pattern="[0-9]{2}:[0-5][0-9]"><small>时:分</small></label><input class="agenda-title" data-agenda="${i}" data-key="title" value="${esc(a.title)}" maxlength="80" aria-label="活动${i+1}标题"><textarea data-agenda="${i}" data-key="detail" maxlength="500" aria-label="活动${i+1}说明">${esc(a.detail)}</textarea></div></div>`).join('')}</div><button id="reset-agenda" class="text-button">↺ 恢复这个主题的灵感流程</button><div class="editor-actions"><button class="text-button" data-step="1">← 返回餐单</button><button class="primary" id="next">生成我的聚会方案 <span>↗</span></button></div>`;}
function result(){
 const t=totals(state),theme=getTheme(state.theme),warnings=planReadiness(state);
 return `<div class="editor-head"><span class="chapter">04 / READY TO GET TOGETHER</span><h2>好啦，就差一起出发。</h2><p>这是属于你们的一局。再看一眼，然后把计划带走。</p></div><section class="result-card"><div class="result-art" style="background:${theme.color}">${themeArt(theme.id)}<span>LET’S GET TOGETHER</span></div><div class="result-card-body"><span class="result-kicker">PRIVATE PLAN / 私人创意计划</span><h3>${theme.name}</h3><p class="result-description">${theme.description}</p><div class="result-facts"><span><small>好日子</small><b>${state.date?esc(state.date):'和朋友一起定'}</b></span><span><small>开始时间</small><b>${esc(state.time)}</b></span><span><small>一起快乐</small><b>${state.people} 位成年人</b></span><span><small>演示餐饮人均</small><b>¥${t.perPerson.toFixed(2)}</b></span></div><div class="result-section"><h4>01 / 一起吃点好的 <span>演示合计 ¥${money(t.total)}</span></h4><div class="result-menu">${MENU.filter(m=>state.quantities[m.id]).map(m=>`<div><span>${m.name} <b>× ${state.quantities[m.id]}</b></span><span>¥${m.price*state.quantities[m.id]}</span></div>`).join('')||'<p>餐单还空着，先添加想吃的吧。</p>'}</div></div><div class="result-section"><h4>02 / 把好时光排进日程</h4><div class="result-agenda">${state.agenda.map(a=>`<div><time>+${esc(a.time)}</time><span><b>${esc(a.title)}</b><p>${esc(a.detail)}</p></span></div>`).join('')}</div></div><div class="result-location">⌖ 灵感地点：${esc(state.city)} · ${esc(state.store)}<small>虚构地点 · 未预约 · 真实安排请自行确认</small></div><p class="result-stamp">18+ 朋友聚会 · 演示价格 · 独立非官方</p></div></section>
 ${warnings.length?`<div class="result-warnings"><b>出发前，再确认这几件事</b><ul>${warnings.map(w=>`<li>${esc(w)}</li>`).join('')}</ul></div>`:''}
 <div class="share-box"><span>把快乐，带给一起快乐的人。</span><p>下载到你的设备，再由你选择是否分享。没有自动发送。</p><div><button id="export" class="primary">↓ 下载文字计划</button><button id="export-card" class="secondary">↓ 保存精美方案卡</button></div><details><summary>更多保存方式</summary><button id="export-json" class="text-button">↓ 下载 JSON 草稿备份</button></details></div><div class="editor-actions"><button class="text-button" data-step="2">← 再改改流程</button><button data-reset class="text-button">↺ 开始新的一局</button></div>`;
}
function showGuide(){
 const old=document.querySelector('#guide');if(old)old.remove();
 const dialog=document.createElement('dialog');dialog.id='guide';dialog.className='guide-dialog';
 dialog.innerHTML='<button class="dialog-close" aria-label="关闭上手引导">×</button><span class="guide-mark">✳</span><span class="eyebrow">A LITTLE GUIDE</span><h2>30 秒，组个快乐局。</h2><p class="guide-intro">给 18 岁以上朋友的私人创意计划。没有注册，也没有预约或付款。</p><ol><li><b>选个主题，定下人数和预算</b><p>日期可以先不填，计划随时能改。</p></li><li><b>搭一份你们想吃的餐单</b><p>按人数推荐，再自由增减演示餐品。</p></li><li><b>加一点小活动，下载带走</b><p>本机保存草稿，由你决定是否分享。</p></li></ol><button class="primary guide-start">知道了，开始组局 ↗</button><p class="guide-note">餐品、价格与地点为演示；官方历史快照在页面下方独立展示。</p>';
 document.body.append(dialog);dialog.querySelector('.dialog-close').onclick=()=>dialog.close();
 dialog.querySelector('.guide-start').onclick=()=>{dialog.close();document.querySelector('#workspace').scrollIntoView({behavior:'smooth'});};
 dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
 dialog.showModal();
}
function updateField(id,value){
 const next={...state,[id]:['people','budget'].includes(id)?Number(value):value},errors=validate(next);
 if(errors.length){notify(errors[0]);render();return;}
 if(id==='time'&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(value)){notify('请选择有效的开始时间');render();return;}
 state=next;
 if(id==='city')state.store=stores[state.city][0];
 if(id==='session')state.time=state.session.startsWith('午间')?'12:00':state.session.startsWith('下午')?'14:00':'18:00';
 persist();render();
 if(id==='people')notify('人数已更新，餐单保留；第二步可按新人数重新推荐。');
}
function bind(){
 document.querySelectorAll('[data-step]').forEach(b=>b.onclick=()=>setStep(Number(b.dataset.step)));
 document.querySelectorAll('[data-theme]').forEach(b=>b.onclick=()=>{
  if(state.theme!==b.dataset.theme){
   if(!confirm('切换主题会更新四段活动流程，餐单和其他设置保持。继续吗？'))return;
   state.theme=b.dataset.theme;state.agenda=themeAgenda(state.theme);
  }persist();render();
 });
 document.querySelectorAll('[data-quick]').forEach(b=>b.onclick=()=>updateField(b.dataset.quick,b.dataset.value));
 for(const id of ['date','time','people','budget','city','store','session','diet']){
  const el=document.getElementById(id);if(el)el.onchange=()=>updateField(id,el.value);
 }
 document.querySelectorAll('[data-quantity]').forEach(b=>b.onclick=()=>{state=changeQuantity(state,b.dataset.quantity,Number(b.dataset.delta));persist();render();});
 document.querySelectorAll('[data-agenda]').forEach(el=>el.onchange=()=>{
  const index=Number(el.dataset.agenda),key=el.dataset.key,value=el.value.trim();
  const next=structuredClone(state.agenda);next[index][key]=value;const errors=agendaErrors(next);
  if(errors.length){notify(errors[0]);el.value=state.agenda[index][key];return;}
  state.agenda=next;persist();
 });
 const next=document.querySelector('#next');if(next)next.onclick=()=>setStep(state.step+1);
 const rec=document.querySelector('#recommend');if(rec)rec.onclick=()=>{
  if(!confirm('按当前人数与偏好重新推荐，会替换餐品数量。继续吗？'))return;
  state=recommend(state);persist();render();notify('已按人数与偏好更新餐单，份数仍可自由调整。');
 };
 const trim=document.querySelector('#trim-extras');if(trim)trim.onclick=()=>{
  state=trimExtras(state);persist();render();notify(totals(state).remaining<0?'已减少可选小食；主食和饮品保留，餐单仍超预算，请继续调整。':'已减少可选小食，餐单已回到演示预算内。');
 };
 const resetAgenda=document.querySelector('#reset-agenda');if(resetAgenda)resetAgenda.onclick=()=>{
  if(confirm('恢复主题灵感流程会覆盖你编辑的活动内容，继续吗？')){state.agenda=themeAgenda(state.theme);persist();render();notify('已恢复主题灵感流程。');}
 };
 document.querySelectorAll('[data-reset]').forEach(b=>b.onclick=()=>{
  if(confirm('清空当前计划，恢复初始演示方案？已下载的文件不会被删除。')){state=fresh();persist();render();notify('已重置，下一局又有新灵感。');}
 });
 document.querySelector('#about').onclick=showGuide;document.querySelector('#hero-guide').onclick=showGuide;
 const ex=document.querySelector('#export');if(ex)ex.onclick=()=>download(shareText(state),'快乐组局计划.txt','text/plain;charset=utf-8');
 const card=document.querySelector('#export-card');if(card)card.onclick=()=>download(planCardDocument(),'快乐组局方案卡.html','text/html;charset=utf-8');
 const json=document.querySelector('#export-json');if(json)json.onclick=()=>download(JSON.stringify({kind:'independent-demonstration-plan',version:1,notice:'Non-official adult creative plan. Demo catalog, prices, store and session. No booking.',plan:state,totals:totals(state)},null,2),'快乐组局计划.json','application/json');
}
function planCardDocument(){
 const theme=getTheme(state.theme),t=totals(state);
 return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(theme.name)} · 快乐组局所</title><style>*{box-sizing:border-box}body{margin:0;padding:32px 18px;background:#fffaf1;color:#29251f;font:16px/1.8 system-ui,"Microsoft YaHei",sans-serif}main{max-width:760px;margin:auto;background:#fffefb;border:1px solid #e6ddcb;border-radius:24px;overflow:hidden}.hero{padding:36px;background:${theme.color}}h1{font-size:42px;margin:12px 0}h2{font-size:20px;margin:28px 0 12px}.body{padding:32px}.facts{display:flex;gap:20px;flex-wrap:wrap}.facts span{padding:12px 18px;background:#fffaf1;border-radius:14px}.menu{padding:12px 0;border-bottom:1px solid #ece4d7;display:flex;justify-content:space-between}.agenda{display:flex;gap:18px;margin:20px 0}.agenda time{color:#875a9f;font-weight:bold;white-space:nowrap}.agenda p{margin:4px 0;color:#665f55}.note{padding:18px;background:#f4efdf;border-radius:14px;font-size:13px}.brand{font-size:12px;letter-spacing:2px}small{color:#776b5b}@media print{body{padding:0;background:white}main{border:0}.hero{-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style><main><div class="hero"><div class="brand">✳ 快乐组局所 / PARTY STUDIO</div><h1>${theme.name}</h1><p>${theme.description}</p><div class="facts"><span>${state.people} 位成年人</span><span>${state.date?esc(state.date):'日期待定'} · ${esc(state.time)}</span><span>演示人均 ¥${t.perPerson.toFixed(2)}</span></div></div><div class="body"><h2>一起吃点好的 <small>演示合计 ¥${money(t.total)}</small></h2>${MENU.filter(m=>state.quantities[m.id]).map(m=>`<div class="menu"><span>${m.name} × ${state.quantities[m.id]}</span><b>¥${m.price*state.quantities[m.id]}</b></div>`).join('')}<h2>把好时光排进日程</h2>${state.agenda.map(a=>`<div class="agenda"><time>+${esc(a.time)}</time><div><b>${esc(a.title)}</b><p>${esc(a.detail)}</p></div></div>`).join('')}<p>灵感地点：${esc(state.city)} / ${esc(state.store)} / ${esc(state.session)}（均为虚构演示）</p><div class="note">18+ 私人创意计划 · 独立非官方 · 所有餐品与价格为演示。${t.remaining<0?'餐单超预算 ¥'+money(-t.remaining)+'。':''}本文件不代表预订、付款、可售套餐或场次承诺。实际价格、配料、过敏原和聚会许可需向真实门店确认。官方儿童主题商品不构成成人方案适用证明。</div></div></main></html>`;
}
function download(data,name,type){
 try{
  const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);notify('已生成本地下载，没有对外发送。');
 }catch{notify('当前浏览器不支持下载，请保留页面或更换浏览器。');}
}
persist();render();
