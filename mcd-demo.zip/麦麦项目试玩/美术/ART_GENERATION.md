# 原创 AI 主题美术记录

本轮通过实际可用的 `image_gen.imagegen` 工具生成三张独立主题图，生成时间为 2026-10-22（Asia/Singapore；UTC 记录 2026-10-21T17:25）。未复制公开 GitHub 或其他第三方项目的代码、截图、摄影、素材或商标。本记录只说明实际来源和用途，不主张官方合作、商品真实性或第三方权利授权。

三张原图均为 1536 × 1024、RGB PNG，保留工具原始输出于 `/workspace/generated_images/`，各仓独立复制至自己的 `assets/`。未做裁剪、转码或图像编辑。图片可能由 CSS 裁切显示，文案由 HTML 提供。

## mcd-order

- 使用文件：`assets/order-hero.png`
- 原始生成文件：`/workspace/generated_images/exec-5a8f7828-f18f-483f-a00d-6e4a35586fad.png`
- SHA-256：`76ffc0d4288959c874d2ba225a1281643f22f749259630505712b550b0ee9cc3`
- 大小：1971075 字节；1536 × 1024 PNG
- 用途：点餐助手主视觉；虚构汉堡/薯条/饮品的概念图，不对应官方商品规格或实际售价。
- 生成工具：`image_gen.imagegen`
- 输入参考图片：无；从文字描述独立生成。
- 生成后处理：仅原样复制；无图像编辑。

完整提示词：

```text
Create a polished original editorial food photograph for a friendly Chinese desktop/mobile ordering demo. Landscape composition, 1536 x 1024 visual target, full bleed image, no interface, no letters, no text, no logo, no watermark. A delicious generic double beef cheeseburger with sesame bun, crisp lettuce, cheese and tomato, a small pile of golden fries in a plain red paper sleeve, and a cold plain white drink cup with a simple straw. Warm ivory tabletop #fffaf1, tasteful tomato red #d8312b and golden yellow #ffcf3d accents, natural soft studio lighting, realistic appetizing food texture, subtle shadows, premium but approachable art direction. Food objects primarily in the center-right, clear quiet warm cream area on the left suitable for HTML headline overlay. This is an independently designed fictional meal for a local demo, not an official fast food product, not packaging or trademark imitation. No price labels. No human hands. Strong composition and restrained props.
```

## mcd-party

- 使用文件：`assets/party-hero.png`
- 原始生成文件：`/workspace/generated_images/exec-622a00a8-5535-4138-bf6c-42d5b3c88571.png`
- SHA-256：`90dc9c0bcf8526217a4ecafa643503fd47285b30ec45c4ec66ccb0632ec36d5c`
- 大小：2355324 字节；1536 × 1024 PNG
- 用途：成人朋友生日聚会氛围图；虚构场景，不是官方门店照片、可订场地或成人套餐证明。
- 生成工具：`image_gen.imagegen`
- 输入参考图片：无；从文字描述独立生成。
- 生成后处理：仅原样复制；无图像编辑。

完整提示词：

```text
Create a sophisticated original lifestyle scene photograph for an adult friends birthday gathering planning demo. Landscape 1536 x 1024 visual target. No text, no typography, no logos, no watermark, no UI. A warm evening table for six adult friends: a beautiful small birthday cake with just a few candles, generic burgers and golden fries on ceramic plates, colorful sparkling non-alcoholic drinks, flowers, tasteful mustard yellow and muted coral party details, soft lilac accents, hanging warm string lights, a cozy contemporary restaurant/private dining atmosphere. The gathering is clearly for grown-up friends, no children, no cartoon children's birthday props, no branded packaging and no suggestion that a real official restaurant package can be booked. Focus on the inviting table and a joyful adult hands-together toast near the back; faces can be softly out of focus. Premium candid editorial photography, warm cream #fffaf1 and dark ink #29251f palette, realistic rich materials, generous composition with breathing space on the left for HTML title overlay. This is a fictional inspirational scene, independently designed, not an actual venue or commercial offer.
```

## mcd-games

- 使用文件：`assets/games-hero.png`
- 原始生成文件：`/workspace/generated_images/exec-80233e34-ba50-49a0-a4a5-9e242c6ee9e5.png`
- SHA-256：`5e3b33eace5567c531696b8f5315032f170e80776f3c1e736d7cf62d6e8eab7b`
- 大小：2389424 字节；1536 × 1024 PNG
- 用途：游乐局大厅概念图；主题插画不是规则示意图。实际推理棋盘仍为9×9、按既有行/列/区域规则运行，插画网格与棋子不可操作。
- 生成工具：`image_gen.imagegen`
- 输入参考图片：无；从文字描述独立生成。
- 生成后处理：仅原样复制；无图像编辑。

完整提示词：

```text
Create an original premium 3D miniature arcade adventure illustration for a friendly Chinese food-themed game demo, landscape 1536 x 1024 target. No text, no letters, no logo, no watermark, no UI. A charming meticulously crafted tabletop arcade world with three connected but distinct mini-scenes: left, a little colorful burger kitchen merging recognizable sesame buns, lettuce, cheese and patties on a golden conveyor; center-right, a milkshake-shaped space rescue craft flying through a deep midnight blue toy cosmos past small star-shaped robots and sparkling laser effects; front-right, a beautifully tactile 9 by 9 logic puzzle board with colored regions and little milkshake crown tokens, clearly a puzzle object, not a real branded game. Rich dimensional materials, tiny detailed mechanical props, crisp silhouettes, soft clay-and-plastic finish, cinematic rim lighting and inviting depth, cream #fffaf1, golden yellow #ffcf3d, tomato red #d8312b, mint green #dfedce and midnight blue colors. Delightful grown-up casual arcade aesthetic, not just flat circles or geometric color blocks. Objects primarily in center-right with quieter dark blue space on left for HTML headline. Entirely independently designed fictional game art, no imitation of known game franchises or fast food mascots.
```

## 接入约束

- 图片仅作装饰/概念视觉，不替代商品名、演示价格、历史采集时间和真实/模拟边界文字。
- 不把装饰物当作可操作游戏目标；实际目标由程序绘制并明确反馈。
- 文件均本地自包含，离线打包时由构建器内联或随包引用，不依赖 CDN。
- 页面须保留非官方试玩、无真实消费的说明；不要将 AI 图作为真实门店或套餐可订证明。

